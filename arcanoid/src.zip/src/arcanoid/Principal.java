package arcanoid;

public class Principal {

	public static void main(String[] args) {

		Game.getInstance().fps();
	}

}
