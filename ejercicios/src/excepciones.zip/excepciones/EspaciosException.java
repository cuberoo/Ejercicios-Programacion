package excepciones;

public class EspaciosException extends Exception {
	
	public EspaciosException(String msg ){
		super(msg);
	}

}
