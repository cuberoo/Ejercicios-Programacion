package excepciones;

public class MinimoDePalabrasException extends Exception{

	public MinimoDePalabrasException(String msg ){
		super(msg);
	}
}
