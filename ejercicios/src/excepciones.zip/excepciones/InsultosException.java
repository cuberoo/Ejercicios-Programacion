package excepciones;

public class InsultosException extends Exception{

	public InsultosException(String msg ){
		super(msg);
	}
}
