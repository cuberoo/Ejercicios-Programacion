package excepciones;

public class NoEstaBombilla extends Exception {

	public NoEstaBombilla(String msg ){
		super(msg);
	}
}
